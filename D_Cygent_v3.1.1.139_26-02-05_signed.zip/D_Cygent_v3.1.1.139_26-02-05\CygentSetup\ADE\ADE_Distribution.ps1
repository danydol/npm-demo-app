try {
    # Define the source and destination paths
    $OLD_destinationPath = "C:\ArcSight\Tools\ADE"
    $destinationPath = "C:\Program Files\CyRay\ADE"

    # Version check: compare destination ADE.ps1 version and packaged version; skip if destination is newer
    function Get-ADEVersionFromFile {
        param([string]$Path)
        if (-not (Test-Path -Path $Path)) { return [version]"0.0.0" }
        try {
            $content = Get-Content -Path $Path -Raw
            if ($content -match '\$ADEVersion\s*=\s*"?([0-9]+(\.[0-9]+)*)"?') { return [version]$matches[1] }
        }
        catch { }
        return [version]"0.0.0"
    }
    $sourceADEPath = Join-Path -Path $PSScriptRoot -ChildPath "ADE.ps1"
    $destADEPath = Join-Path -Path $destinationPath -ChildPath "ADE.ps1"
    $sourceVersion = Get-ADEVersionFromFile -Path $sourceADEPath
    $destVersion = Get-ADEVersionFromFile -Path $destADEPath

    Write-Output "Current ADE: $destVersion"
    Write-Output "Package ADE: $sourceVersion"
    Write-Output "---------------------"

    if ($destVersion -ge $sourceVersion) {
        Write-Output "Update not required based on version. Verifying existing installation..."
        $forceUpdate = $false

        # Define required files and tasks for verification
        $requiredFiles = @("ADE.ps1", "groups.csv")
        $requiredTasks = @("ADEnrichment", "ADEnrichment incremental")
        $taskSchedulerFolder = "CyRay"
        $taskFolderPath = "\" + $taskSchedulerFolder + "\"

        # Verify files exist
        foreach ($file in $requiredFiles) {
            $filePath = Join-Path -Path $destinationPath -ChildPath $file
            if (-not (Test-Path -Path $filePath)) {
                Write-Warning "Verification failed: Required file is missing: $filePath"
                $forceUpdate = $true
            }
        }

        # Verify tasks exist
        foreach ($taskName in $requiredTasks) {
            $task = Get-ScheduledTask -TaskPath $taskFolderPath -TaskName $taskName -ErrorAction SilentlyContinue
            if (-not $task) {
                Write-Warning "Verification failed: Required scheduled task is missing: $taskName"
                $forceUpdate = $true
            }
        }

        if ($forceUpdate) {
            Write-Output "Forcing update due to incomplete installation."
        } else {
            Write-Output "Installation is complete. Skipping ADE update."
            exit 0
        }
    }
    else {
        Write-Output "ADE update required"
    }

    $ADE_ps1 = "ADE.ps1"
    $ADE_xml = "CyRay - ADE.xml"
    $ADE1_xml = "CyRay - ADE Incremental.xml"
    $groups = "groups.csv"




    # Function to check if a service exists and delete it
    function Remove-ServiceIfExists {
        param (
            [string]$serviceName,
            [string]$displayName
        )
        $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
        if ($service -and $service.DisplayName -eq $displayName) {
            Write-Output "Stopping service: $serviceName"
            Stop-Service -Name $serviceName -Force
            Write-Output "Deleting service: $serviceName"
            sc.exe delete $serviceName
            Start-Sleep -Seconds 2
            # Verify the service has been deleted
            $serviceCheck = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
            if ($serviceCheck) {
                throw "Failed to delete service $serviceName"
            }
            Write-Output "Service $serviceName deleted successfully"
        }
        else {
            Write-Output "Service $serviceName with display name $displayName does not exist"
        }
    }

    # Remove the service if it exists
    Remove-ServiceIfExists -serviceName "ADEnrichment" -displayName "CyRay Mobula ADEnrichment"
    # Delete old ADE directory if it exists
    if (Test-Path -Path $OLD_destinationPath) {
        Remove-Item -Path $OLD_destinationPath -Recurse -Force -Confirm:$false
    }
    # Check if the destination folder exists
    if (-Not (Test-Path -Path $destinationPath)) {
        # If the folder doesn't exist, create it
        New-Item -ItemType Directory -Path $destinationPath -Force -Confirm:$false
        Write-Output "Created destination folder: $destinationPath"
    }
    else {
        # If the path does exist, create a backup zip with current date/time containing all current files
        try {
            $timestamp = Get-Date -Format "yyyy-MM-dd_HHmmss"
            $backupFolderPath = Join-Path -Path $destinationPath -ChildPath "backups"
            if (-Not (Test-Path -Path $backupFolderPath)) {
                New-Item -ItemType Directory -Path $backupFolderPath -Force -Confirm:$false | Out-Null
                Write-Output "Created backups folder: $backupFolderPath"
            }
            $backupFileName = "backup $timestamp.zip"
            $backupFilePath = Join-Path -Path $backupFolderPath -ChildPath $backupFileName
            Write-Output "Creating backup: $backupFilePath"
            # Collect items to back up, excluding the 'backups' folder itself
            $itemsToBackup = Get-ChildItem -LiteralPath $destinationPath -Force | Where-Object { $_.Name -ne 'backups' }
            if (-not $itemsToBackup -or $itemsToBackup.Count -eq 0) {
                Write-Output "No items to back up (excluding 'backups'); skipping zip creation."
            }
            else {
                Compress-Archive -Path $itemsToBackup.FullName -DestinationPath $backupFilePath -Force
                Write-Output "Backup created successfully"
            }
        }
        catch {
            Write-Warning "Failed to create backup zip: $_"
        }

        # If the path does exist, search for files named ADE.ps1 and groups.csv and delete them
        $filesToDelete = @($ADE_ps1)
        foreach ($file in $filesToDelete) {
            $filePath = Join-Path -Path $destinationPath -ChildPath $file
            if (Test-Path -Path $filePath) {
                Write-Output "Deleting file: $filePath"
                Remove-Item -Path $filePath -Force
            }
            else {
                Write-Output "File not found, skipping deletion: $filePath"
            }
        }
    }

    # Define the Task Scheduler folder for stopping tasks
    $taskSchedulerFolderForStop = "CyRay"
    $taskFolderPathForStop = "\" + $taskSchedulerFolderForStop + "\"

    # Stop running tasks to prevent file locks
    $tasksToStop = @("ADEnrichment", "ADEnrichment incremental")
    foreach ($taskName in $tasksToStop) {
        $task = Get-ScheduledTask -TaskPath $taskFolderPathForStop -TaskName $taskName -ErrorAction SilentlyContinue
        if ($task -and $task.State -eq 'Running') {
            Write-Output "Stopping running task to prevent file lock: $taskName"
            Stop-ScheduledTask -TaskPath $taskFolderPathForStop -TaskName $taskName
        }
    }

    # Copy the files to the destination folder
    try {
        Write-Output "Copying files to $destinationPath"
        Copy-Item -Path "$PSScriptRoot\$ADE_ps1" -Destination $destinationPath -Force

        # Only if groups.csv not exists already
        if (-Not (Test-Path -Path "$destinationPath\$groups")) {
            Copy-Item -Path "$PSScriptRoot\$groups" -Destination $destinationPath -Force
        }

        Write-Output "Files copied successfully"
    }
    catch {
        Write-Error "Error copying files: $_"
        exit 1
    }

    # Define the Task Scheduler folder
    $taskSchedulerFolder = "CyRay"
    $taskFolderPath = "\" + $taskSchedulerFolder + "\"

    # Unregister obsolete task if it exists
    $obsoleteTaskName = "ADEnrichment KA"
    $task = Get-ScheduledTask -TaskPath $taskFolderPath -TaskName $obsoleteTaskName -ErrorAction SilentlyContinue
    if ($task) {
        Write-Output "Unregistering obsolete task $obsoleteTaskName"
        Unregister-ScheduledTask -TaskPath $taskFolderPath -TaskName $obsoleteTaskName -Confirm:$false
    }

    # Import the tasks from XML files, creating or updating them
    $taskADEPath = "$PSScriptRoot\$ADE_xml"
    $taskADE1Path = "$PSScriptRoot\$ADE1_xml"

    Write-Output "Registering/Updating task ADEnrichment"
    try {
        Register-ScheduledTask -Xml (Get-Content -Path $taskADEPath -Raw) -TaskName "ADEnrichment" -TaskPath $taskFolderPath -Force
        Write-Output "Task ADEnrichment registered/updated successfully"
    }
    catch {
        Write-Error "Failed to register/update task ADEnrichment: $_"
    }

    Write-Output "Registering/Updating task ADEnrichment incremental"
    try {
        Register-ScheduledTask -Xml (Get-Content -Path $taskADE1Path -Raw) -TaskName "ADEnrichment incremental" -TaskPath $taskFolderPath -Force
        Write-Output "Task ADEnrichment incremental registered/updated successfully"
    }
    catch {
        Write-Error "Failed to register/update task ADEnrichment incremental: $_"
    }

    #Install AD-Tools
    Add-WindowsFeature RSAT-Role-Tools

}
catch {
    Write-Error "Error occurred: $($_.Exception.Message)"
}
finally {
    Write-Output ""
    Write-Output "ADE Installation Finished, waiting 10 seconds before closing.."
    Start-Sleep -Seconds 10
}
