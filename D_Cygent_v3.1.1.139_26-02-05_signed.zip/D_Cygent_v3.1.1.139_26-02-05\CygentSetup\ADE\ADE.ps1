Param(
    [Parameter(Mandatory = $false)]
    [ValidateSet("Full", "Incremental")]
    [string]$CycleType = "Full"
)

$ProgressPreference = 'SilentlyContinue'
Import-Module ActiveDirectory

#region Variables
$rootDomain = Get-ADDomain
$rootForest = ($rootDomain).Forest
$currentForest = $rootForest # Keep generic name consistent
$AllDomains = (Get-ADForest).Domains
$LogName = "CyRay Services"
$ADEVersion = "2.1.1"
#endregion

#region Event Log Setup
$EventSources = @("ADUsersExport", "ADComputersExport", "ADDCsExport", "ADGroupsExport", "ADDomainsExport")
foreach ($Source in $EventSources) {
    if ([System.Diagnostics.EventLog]::SourceExists($Source) -eq $false) {
        New-EventLog -LogName $LogName -Source $Source
    }
}
#endregion

#region Watermark Setup
$ScriptRunTime = Get-Date
$WatermarkFile = Join-Path $PSScriptRoot "watermark.json"
$GlobalSuccess = $true
$LastRunTime = $null

if (Test-Path $WatermarkFile) {
    try {
        # Read the watermark file
        $json = Get-Content $WatermarkFile -Raw | ConvertFrom-Json
        if ($json.LastSuccessTime) {
            $LastRunTime = Get-Date $json.LastSuccessTime
        }
    }
    catch {
        Write-Warning "Failed to read watermark file. Defaulting to 1 hour lookback."
    }
}

# Fallback if no watermark exists
if (-not $LastRunTime) {
    $LastRunTime = (Get-Date).AddHours(-1)
}

# Format for LDAP (Generalized Time)
$ldapDate = $LastRunTime.ToString("yyyyMMddHHmmss.0Z")
#endregion

#region Functions
function Write-CustomEventLog($eventId, $eventSource, $attributes) {
    $message = $attributes | ConvertTo-Json
    Write-EventLog -LogName $LogName -Source $eventSource -EventId $eventId -EntryType Information -Message $message
}

filter Process-UserItem {
    try {
        $user = $_
        $userAttributes = [ordered]@{}
        foreach ($prop in $userProperties) {
            if ($prop -eq 'SID') {
                $userAttributes[$prop] = $user.SID.Value
            }
            elseif ($prop -in 'logonCount', 'adminCount') {
                $userAttributes[$prop] = if ($null -ne $user.$prop) { [int]$user.$prop } else { 0 }
            }
            else {
                $userAttributes[$prop] = $user.$prop
            }
        }
        # Use simple variable from parent scope or passed object
        $userAttributes.Domain = $script:ProcessingDomainDN
        $userAttributes.Forest = $script:currentForest

        Write-CustomEventLog 40101 $CurrentEventSource $userAttributes
        $script:UserCount++
    }
    catch {
        $script:UserErrorCount++
    }
}

filter Process-ComputerItem {
    try {
        $computer = $_
        $computerAttributes = [ordered]@{}
        foreach ($prop in $computerProperties) {
            if ($prop -eq 'SID') {
                $computerAttributes[$prop] = $computer.SID.Value
            }
            elseif ($prop -eq 'logonCount') {
                $computerAttributes[$prop] = if ($null -ne $computer.$prop) { [int]$computer.$prop } else { 0 }
            }
            else {
                $computerAttributes[$prop] = $computer.$prop
            }
        }
        $computerAttributes.Domain = $script:ProcessingDomainDN
        $computerAttributes.Forest = $script:currentForest

        Write-CustomEventLog 40101 $CurrentEventSource $computerAttributes
        $script:ComputerCount++
    }
    catch {
        $script:ComputerErrorCount++
    }
}
#endregion

#region AD Users
$CurrentEventSource = "ADUsersExport"
$userProperties = @(
    'AccountExpirationDate', 'AccountLockoutTime', 'AccountNotDelegated',
    'AllowReversiblePasswordEncryption', 'CannotChangePassword', 'City',
    'Company', 'Country', 'Created', 'Deleted', 'Department', 'Description',
    'DisplayName', 'DistinguishedName', 'EmailAddress', 'Enabled',
    'LastLogonDate', 'LockedOut', 'MobilePhone', 'Modified', 'Name',
    'ObjectClass', 'PasswordExpired', 'PasswordLastSet', 'PasswordNeverExpires',
    'PasswordNotRequired', 'SamAccountName', 'SID', 'Title', 'userAccountControl',
    'whenChanged', 'adminCount', 'logonCount', 'UserPrincipalName', 'servicePrincipalName', 'uidNumber',
    'msDS-AllowedToDelegateTo', 'manager', 'msDS-UserPasswordExpiryTimeComputed'
)

foreach ($DomainDN in $AllDomains) {
    try {
        $script:ProcessingDomainDN = $DomainDN
        $script:UserCount = 0
        $script:UserErrorCount = 0
        
        # Get Domain Object for details if needed, simplifed to just use DN for export
        
        if ($CycleType -eq "Full") {
            $startMessage = [ordered]@{ Status = "Start Full Cycle"; ADEVersion = $ADEVersion; Domain = $DomainDN } | ConvertTo-Json -Compress
            Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40201 -EntryType Information -Message $startMessage
            Get-ADUser -Server $DomainDN -Filter * -Properties $userProperties | Process-UserItem
        }
        else {
            # Use watermark date
            $startMessage = [ordered]@{ Status = "Start Incremental Cycle"; ADEVersion = $ADEVersion; Domain = $DomainDN; Watermark = $LastRunTime } | ConvertTo-Json -Compress
            Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40203 -EntryType Information -Message $startMessage
            Get-ADUser -Server $DomainDN -LDAPFilter "(whenChanged>=$ldapDate)" -Properties $userProperties | Process-UserItem
        }
        $finishMessage = [ordered]@{ TotalObjects = $script:UserCount; TotalErrors = $script:UserErrorCount; ADEVersion = $ADEVersion; Domain = $DomainDN } | ConvertTo-Json -Compress
        if ($CycleType -eq "Full") { Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40202 -EntryType Information -Message $finishMessage }
        else { Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40204 -EntryType Information -Message $finishMessage }
    }
    catch {
        $GlobalSuccess = $false
        $errorMessage = $_.Exception.Message
        Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40999 -EntryType Error -Message "AD user export for domain $DomainDN failed with error: $errorMessage" 
    }
}
#endregion

#region AD Computers
$CurrentEventSource = "ADComputersExport"
$computerProperties = @(
    'Name', 'SamAccountName', 'Created', 'Modified', 'Enabled', 'userAccountControl',
    'SID', 'OperatingSystemVersion', 'OperatingSystem', 'ObjectClass', 'logonCount',
    'LastLogonDate', 'isCriticalSystemObject', 'IPv4Address', 'Description',
    'DisplayName', 'DistinguishedName', 'DNSHostName', 'Deleted', 'whenChanged',
    'managedBy'
)

foreach ($DomainDN in $AllDomains) {
    try {
        $script:ProcessingDomainDN = $DomainDN
        $script:ComputerCount = 0
        $script:ComputerErrorCount = 0
        
        if ($CycleType -eq "Full") {
            $startMessage = [ordered]@{ Status = "Start Full Cycle"; ADEVersion = $ADEVersion; Domain = $DomainDN } | ConvertTo-Json -Compress
            Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40201 -EntryType Information -Message $startMessage
            Get-ADComputer -Server $DomainDN -Filter * -Properties $computerProperties | Process-ComputerItem
        }
        else {
            # Use watermark date
            $startMessage = [ordered]@{ Status = "Start Incremental Cycle"; ADEVersion = $ADEVersion; Domain = $DomainDN; Watermark = $LastRunTime } | ConvertTo-Json -Compress
            Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40203 -EntryType Information -Message $startMessage
            Get-ADComputer -Server $DomainDN -LDAPFilter "(whenChanged>=$ldapDate)" -Properties $computerProperties | Process-ComputerItem
        }
        $finishMessage = [ordered]@{ TotalObjects = $script:ComputerCount; TotalErrors = $script:ComputerErrorCount; ADEVersion = $ADEVersion; Domain = $DomainDN } | ConvertTo-Json -Compress
        if ($CycleType -eq "Full") { Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40202 -EntryType Information -Message $finishMessage }
        else { Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40204 -EntryType Information -Message $finishMessage }
    }
    catch {
        $GlobalSuccess = $false
        $errorMessage = $_.Exception.Message
        Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40999 -EntryType Error -Message "AD computer export for domain $DomainDN failed with error: $errorMessage" 
    }
}
#endregion

#region AD DCs
if ($CycleType -eq "Full") {
    $CurrentEventSource = "ADDCsExport"
    foreach ($DomainDN in $AllDomains) {
        $startMessage = [ordered]@{ Status = "Start Full Cycle"; ADEVersion = $ADEVersion; Domain = $DomainDN } | ConvertTo-Json -Compress
        Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40201 -EntryType Information -Message $startMessage
        try {
            $DCCount = 0
            $DCErrorCount = 0
            $DCs = Get-ADDomainController -Filter * -Server $DomainDN | Select-Object IPv4Address, HostName, Name, Enabled, Domain, Forest
            foreach ($DC in $DCs) {
                # Create a hashtable to store attributes
                $DCsAttributes = @{}
                $DCsAttributes.Domain = $DC.Domain
                $DCsAttributes.Forest = $DC.Forest
                $DCsAttributes.IPv4Address = $DC.IPv4Address
                $DCsAttributes.HostName = $DC.HostName
                $DCsAttributes.Name = $DC.Name
                $DCsAttributes.Enabled = $DC.Enabled
                
                Write-CustomEventLog 40101 $CurrentEventSource $DCsAttributes
                $DCCount++
            }
            $finishMessage = [ordered]@{ TotalObjects = $DCCount; TotalErrors = $DCErrorCount; ADEVersion = $ADEVersion; Domain = $DomainDN } | ConvertTo-Json -Compress
            Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40202 -EntryType Information -Message $finishMessage
        }
        catch {
            $GlobalSuccess = $false
            $errorMessage = $_.Exception.Message
            Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40999 -EntryType Error -Message "AD DC export for domain $DomainDN failed with error: $errorMessage"
        }
    }
}

#region AD Users in Groups
if ($CycleType -eq "Full") {
    $CurrentEventSource = "ADGroupsExport"
    
    # We log a general start message, or per domain? 
    # Since groups come from a CSV, they could be in ANY domain. We will loop domains to find them.
    # However, to be cleaner, we can just process the CSV one by one.
    
    $startMessage = [ordered]@{ Status = "Start Full Cycle"; ADEVersion = $ADEVersion; Forest = $rootForest; Domain = $rootDomain.DNSRoot } | ConvertTo-Json -Compress
    Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40201 -EntryType Information -Message $startMessage
    
    $csvPath = Join-Path $PSScriptRoot "groups.csv"
    if (Test-Path $csvPath) {
        $GroupCount = 0
        $GroupErrorCount = 0
        $csvGroups = Import-Csv $csvPath
        foreach ($group in $csvGroups) {
            $groupName = $group.groupName
            $groupType = $group.groupType
            $groupMemberProperties = @('SID', 'name', 'objectClass', 'objectGUID', 'SamAccountName', 'distinguishedName')

            if ($groupName) {
                # Check if group exists in ANY domain
                $foundGroup = $null
                $foundDomain = $null
                
                foreach ($chkDomain in $AllDomains) {
                    try {
                        $foundGroup = Get-ADGroup -Identity $groupName -Server $chkDomain -ErrorAction Stop
                        $foundDomain = $chkDomain
                        break # Found it, stop searching
                    }
                    catch {
                        # Not in this domain, continue
                    }
                }

                if (-not $foundGroup) {
                    $jsonPayload = [ordered]@{
                        GroupName = $groupName
                        GroupType = $groupType
                        Status    = "Group does not exist in any domain"
                        Forest    = $rootForest
                        Domain    = $rootDomain.DNSRoot
                    } | ConvertTo-Json -Compress
                    Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40998 -EntryType Warning -Message $jsonPayload
                    continue
                }

                # Found group, process members using the specific domain found
                try {
                    $UsersInGroup = @(Get-ADGroupMember -identity $groupName -Server $foundDomain -Recursive | Select-Object $groupMemberProperties)
                    $memberCount = $UsersInGroup.Count
                    
                    $jsonPayload = [ordered]@{
                        GroupName   = $groupName
                        GroupType   = $groupType
                        MemberCount = $memberCount
                        Domain      = $foundDomain
                    } | ConvertTo-Json -Compress
                    Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40205 -EntryType Information -Message $jsonPayload

                    foreach ($UsersG in $UsersInGroup) {
                        $UsersGAttributes = [ordered]@{}
                        foreach ($prop in $groupMemberProperties) {
                            if ($prop -eq 'SID') {
                                $UsersGAttributes[$prop] = $UsersG.SID.Value
                            }
                            elseif ($prop -eq 'distinguishedName') {
                                $UsersGAttributes['DN'] = $UsersG.distinguishedName
                            }
                            else {
                                $UsersGAttributes[$prop] = $UsersG.$prop
                            }
                        }
                        $UsersGAttributes.Domain = $foundDomain
                        $UsersGAttributes.Forest = $currentForest
                        $UsersGAttributes.GroupName = $groupName
                        $UsersGAttributes.GroupType = $groupType
                        Write-CustomEventLog 40101 $CurrentEventSource $UsersGAttributes
                    }
                }
                catch {
                    $GlobalSuccess = $false
                    $GroupErrorCount++
                    $errorMessage = $_.Exception.Message
                    Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40999 -EntryType Error -Message "AD Users in Group '$groupName' failed with error: $errorMessage" 
                }
            }
            $GroupCount++
        }
        $finishMessage = [ordered]@{ TotalObjects = $GroupCount; TotalErrors = $GroupErrorCount; ADEVersion = $ADEVersion; Forest = $rootForest; Domain = $rootDomain.DNSRoot } | ConvertTo-Json -Compress
        Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40202 -EntryType Information -Message $finishMessage
    }
    else {
        $jsonPayload = [ordered]@{
            Status = "groups.csv file not found"
            Forest = $rootForest
            Domain = $rootDomain.DNSRoot
        } | ConvertTo-Json -Compress
        Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40998 -EntryType Warning -Message $jsonPayload

        $finishMessage = [ordered]@{ TotalObjects = 0; TotalErrors = 0; ADEVersion = $ADEVersion; Forest = $rootForest; Domain = $rootDomain.DNSRoot } | ConvertTo-Json -Compress
        Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40202 -EntryType Information -Message $finishMessage
    }
}
#endregion

#region AD Domains
if ($CycleType -eq "Full") {
    $CurrentEventSource = "ADDomainsExport"
    
    # Logic effectively iterates domains anyway, just ensuring branding is correct
    $startMessage = [ordered]@{ Status = "Start Full Cycle"; ADEVersion = $ADEVersion; Forest = $rootForest; Domain = $rootDomain.DNSRoot } | ConvertTo-Json -Compress
    Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40201 -EntryType Information -Message $startMessage

    try {
        $DomainCount = 0
        $DomainErrorCount = 0
        # Re-use $AllDomains if needed, but the original logic was specific to get details
        foreach ($Domain in $AllDomains) {
            $DomainDetails = Get-ADDomain -Identity $Domain -Server $Domain | Select-Object Name, DNSRoot, Forest, DomainControllersContainer
            $DomainAttributes = @{}
            $DomainAttributes.Name = $DomainDetails.Name
            $DomainAttributes.DNSRoot = $DomainDetails.DNSRoot
            $DomainAttributes.Forest = $DomainDetails.Forest
            $DomainAttributes.DomainControllersContainer = $DomainDetails.DomainControllersContainer
            $DomainAttributes.ADEVersion = $ADEVersion
            $DomainAttributes.Domain = $DomainDetails.Name
            
            # Additional logic to get AD functional level if needed, but existing is fine
            
            Write-CustomEventLog 40101 $CurrentEventSource $DomainAttributes
            $DomainCount++
        }
        $finishMessage = [ordered]@{ TotalObjects = $DomainCount; TotalErrors = $DomainErrorCount; ADEVersion = $ADEVersion; Forest = $rootForest; Domain = $rootDomain.DNSRoot } | ConvertTo-Json -Compress
        Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40202 -EntryType Information -Message $finishMessage
    }
    catch {
        $GlobalSuccess = $false
        $errorMessage = $_.Exception.Message
        Write-EventLog -LogName $LogName -Source $CurrentEventSource -EventId 40999 -EntryType Error -Message "AD Domain export failed with error: $errorMessage"
    }
}

#endregion

#region Watermark Update
if ($GlobalSuccess) {
    try {
        $watermarkData = @{
            LastSuccessTime = $ScriptRunTime
            ADEVersion      = $ADEVersion
        }
        $watermarkData | ConvertTo-Json | Set-Content $WatermarkFile -Force
    }
    catch {
        Write-Warning "Failed to update watermark file: $($_.Exception.Message)"
    }
}
#endregion
