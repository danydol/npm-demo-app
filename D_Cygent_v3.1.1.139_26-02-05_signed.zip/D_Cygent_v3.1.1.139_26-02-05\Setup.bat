cd CygentSetup
"Cygent Setup.exe"